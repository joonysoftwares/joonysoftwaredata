@echo off
setlocal
cd /d "%~dp0\Intel"
call i3782.bat /y
timeout 2
EEUPDATE.exe /NIC=1 /mac=345A60865F0F
timeout 2
endlocal