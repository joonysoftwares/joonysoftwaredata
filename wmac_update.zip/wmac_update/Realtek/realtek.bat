@echo off
setlocal
cd /d "%~dp0\Realtek\AMD64"
RTNicPgW64 /efuse /nodeid 485B39C59088
RTNicPgW64 /# 1 /efuse /nodeid 485B39C59088
RTNicPgW64 /# 2 /efuse /nodeid 485B39C59088
RTNicPgW64 /# 3 /efuse /nodeid 485B39C59088


endlocal